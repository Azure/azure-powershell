﻿// ----------------------------------------------------------------------------------
//
// Copyright Microsoft Corporation
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ----------------------------------------------------------------------------------

using Microsoft.WindowsAzure.Commands.ScenarioTest;
using System;
using System.Collections.Generic;
using System.IO;
using Xunit;

namespace Microsoft.Azure.Commands.Compute.Test.ScenarioTests
{
    public class RunnerTests
    {
        public RunnerTests(Xunit.Abstractions.ITestOutputHelper output)
        {
        }

        [Fact]
        [Trait(Category.AcceptanceType, Category.CheckIn)]
        public void ExecuteRunnerTests()
        {
            var mode = Environment.GetEnvironmentVariable("AZURE_TEST_MODE");
            var csmAuth = Environment.GetEnvironmentVariable("TEST_CSM_ORGID_AUTHENTICATION");

            if (mode == null || csmAuth == null || mode.ToLower() != "record")
            {
                return;
            }

            var testFile = File.ReadAllLines("ScenarioTests\\RunnerTests.csv");
            foreach (var line in testFile)
            {
                var tokens = line.Split(';');
                var className = tokens[0];
                var type = Type.GetType(className);
                var constructorInfo = type.GetConstructor(Type.EmptyTypes);
                for (int i = 1; i < tokens.Length; i++)
                {
                    var method = tokens[i];
                    var testClassInstance = constructorInfo.Invoke(new object[] { });
                    var testMethod = type.GetMethod(method);

                    Console.WriteLine("Invoking method : " + testMethod);

                    testMethod.Invoke(testClassInstance, new object[] { });

                    Console.WriteLine("Method " + testMethod + " has finished");
                }
            }
        }

        private void FixCSMAuthEnvVariable(IDictionary<string, string> envDictionary)
        {
            var str = string.Empty;
            foreach (var entry in envDictionary)
            {
                if (entry.Key != "AADClientId" && entry.Key != "ApplicationSecret")
                {
                    str += string.Format("{0}={1};", entry.Key, entry.Value);
                }
            }

            Environment.SetEnvironmentVariable("TEST_CSM_ORGID_AUTHENTICATION", str);
        }
    }
}
